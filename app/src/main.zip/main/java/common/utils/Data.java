package common.utils;

/**
 * The type Data.
 */
public class Data {
    /**
     * The constant URL_base.
     */
    public static String URL_base = "http://www.w3schools.com/";
}
